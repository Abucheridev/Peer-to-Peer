const supportAreas = [
  {
    number: "01",
    title: "Breaking destructive patterns",
    description:
      "Connect with people who understand the difficult work of changing habits and making a fresh start.",
  },
  {
    number: "02",
    title: "Recovery and rebuilding",
    description:
      "Find encouragement from lived experience as you work toward stability, confidence and new routines.",
  },
  {
    number: "03",
    title: "Personal growth",
    description:
      "Talk through challenges, strengthen your direction and take practical steps forward.",
  },
];

const steps = [
  {
    number: "01",
    title: "Find understanding",
    description:
      "Explore mentor profiles and learn about the experiences, approach and support they offer.",
  },
  {
    number: "02",
    title: "Choose your connection",
    description:
      "Select a mentorship package and the communication format that works for you.",
  },
  {
    number: "03",
    title: "Move forward",
    description:
      "Build a supportive connection and work toward meaningful, personal progress.",
  },
];

export default function Home() {
  return (
    <main>
      <header className="site-header">
        <a className="brand" href="#" aria-label="PEER TO PEER home">
          <span className="brand-mark">P</span>
          <span>PEER <span className="brand-light">TO PEER</span></span>
        </a>
        <nav className="desktop-nav" aria-label="Main navigation">
          <a href="#how-it-works">How it works</a>
          <a href="#support">Find support</a>
          <a href="#become-a-mentor">Become a mentor</a>
        </nav>
        <div className="header-actions">
          <a className="login-link" href="mailto:hello@peertopeer.example">Log in</a>
          <a className="button button-small button-dark" href="#get-started">Get started</a>
        </div>
      </header>

      <section className="hero">
        <div className="hero-copy">
          <div className="eyebrow"><span className="eyebrow-dot" /> A community built on lived experience</div>
          <h1>You don’t have to figure it all out <em>alone.</em></h1>
          <p className="hero-description">
            Real people. Shared experiences. Second chances. Find understanding,
            guidance and encouragement from people who have walked a similar path.
          </p>
          <div className="hero-actions" id="get-started">
            <a className="button button-primary" href="#support">Find a mentor <span aria-hidden="true">↗</span></a>
            <a className="text-link" href="#become-a-mentor">Share your experience <span aria-hidden="true">→</span></a>
          </div>
          <div className="hero-note">
            <span className="note-icon">✳</span>
            A judgement-free starting point for your next chapter.
          </div>
        </div>
        <div className="hero-art" aria-label="Abstract illustration representing connection and growth">
          <div className="art-orbit orbit-one" />
          <div className="art-orbit orbit-two" />
          <div className="art-core"><span>PEER</span><strong>↗</strong></div>
          <div className="art-card art-card-top"><span className="mini-dot" /> Shared experience</div>
          <div className="art-card art-card-bottom"><span className="mini-star">✳</span><span>Every step forward<br /><strong>counts.</strong></span></div>
          <div className="art-spark spark-one">✳</div>
          <div className="art-spark spark-two">✦</div>
        </div>
      </section>

      <section className="trust-strip" aria-label="Our principles">
        <div><span>01</span> Lived experience matters</div>
        <div><span>02</span> Your story is yours</div>
        <div><span>03</span> Progress without judgement</div>
      </section>

      <section className="section support-section" id="support">
        <div className="section-heading">
          <div>
            <div className="eyebrow">A place to begin again</div>
            <h2>Support that starts<br />with <em>understanding.</em></h2>
          </div>
          <p>Everyone’s journey is different. Start with the kind of support that speaks to where you are today.</p>
        </div>
        <div className="support-grid">
          {supportAreas.map((item) => (
            <article className="support-card" key={item.number}>
              <span className="card-number">{item.number}</span>
              <div className="card-arrow" aria-hidden="true">↗</div>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="how-section" id="how-it-works">
        <div className="section section-inner">
          <div className="section-heading">
            <div>
              <div className="eyebrow eyebrow-light">Simple by design</div>
              <h2>A connection can<br />change your <em>direction.</em></h2>
            </div>
            <p>Take it one step at a time. You stay in control of the support you choose and the pace you set.</p>
          </div>
          <div className="steps-grid">
            {steps.map((step) => (
              <article className="step-card" key={step.number}>
                <span>{step.number}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="mentor-cta" id="become-a-mentor">
        <div>
          <div className="eyebrow">Your experience has value</div>
          <h2>Someone out there<br />could learn from <em>your story.</em></h2>
          <p>Become a peer mentor and help someone take their next step forward.</p>
        </div>
        <a className="button button-dark" href="mailto:mentors@peertopeer.example">Explore becoming a mentor <span aria-hidden="true">↗</span></a>
      </section>

      <footer className="site-footer">
        <a className="brand footer-brand" href="#">
          <span className="brand-mark">P</span>
          <span>PEER <span className="brand-light">TO PEER</span></span>
        </a>
        <p>Real People. Shared Experiences. Second Chances.</p>
        <span className="copyright">© {new Date().getFullYear()} PEER TO PEER</span>
      </footer>
    </main>
  );
}
