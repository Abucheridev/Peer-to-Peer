import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "PEER TO PEER | Real People. Shared Experiences. Second Chances.",
  description:
    "A supportive peer mentorship community built around lived experience, understanding and personal growth.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
